import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

/// Replace with your own Firebase project configuration using:
/// flutterfire configure
/// Then import firebase_options.dart and initialize with
/// DefaultFirebaseOptions.currentPlatform.
const String adminUid = String.fromEnvironment('EF_ARENA_ADMIN_UID');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const EfArenaApp());
}

class EfArenaApp extends StatelessWidget {
  const EfArenaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'EF ARENA',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF090B0F),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFE5BE55),
          brightness: Brightness.dark,
          primary: const Color(0xFFE5BE55),
          secondary: const Color(0xFFB7F34A),
          surface: const Color(0xFF171B22),
        ),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF090B0F),
          foregroundColor: Colors.white,
          centerTitle: false,
        ),
        cardTheme: CardTheme(
          color: const Color(0xFF171B22),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
        ),
      ),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        if (snapshot.data == null) return const PhoneLoginPage();
        return const MainShell();
      },
    );
  }
}

class PhoneLoginPage extends StatefulWidget {
  const PhoneLoginPage({super.key});

  @override
  State<PhoneLoginPage> createState() => _PhoneLoginPageState();
}

class _PhoneLoginPageState extends State<PhoneLoginPage> {
  final phoneController = TextEditingController();
  final otpController = TextEditingController();
  String? verificationId;
  bool busy = false;
  String message = '';

  @override
  void dispose() {
    phoneController.dispose();
    otpController.dispose();
    super.dispose();
  }

  Future<void> sendOtp() async {
    final phone = phoneController.text.trim();
    if (!phone.startsWith('+') || phone.length < 10) {
      setState(() => message = 'দেশের কোডসহ নম্বর লিখুন। যেমন: +8801XXXXXXXXX');
      return;
    }
    setState(() { busy = true; message = ''; });
    try {
      await FirebaseAuth.instance.verifyPhoneNumber(
        phoneNumber: phone,
        timeout: const Duration(seconds: 60),
        verificationCompleted: (credential) async {
          await FirebaseAuth.instance.signInWithCredential(credential);
        },
        verificationFailed: (error) {
          if (mounted) setState(() => message = error.message ?? 'OTP পাঠানো যায়নি।');
        },
        codeSent: (id, resendToken) {
          if (mounted) setState(() {
            verificationId = id;
            message = 'OTP পাঠানো হয়েছে।';
          });
        },
        codeAutoRetrievalTimeout: (id) => verificationId = id,
      );
    } catch (e) {
      setState(() => message = 'সমস্যা হয়েছে: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> verifyOtp() async {
    if (verificationId == null || otpController.text.trim().length < 6) {
      setState(() => message = '৬ সংখ্যার OTP লিখুন।');
      return;
    }
    setState(() { busy = true; message = ''; });
    try {
      final credential = PhoneAuthProvider.credential(
        verificationId: verificationId!,
        smsCode: otpController.text.trim(),
      );
      await FirebaseAuth.instance.signInWithCredential(credential);
    } on FirebaseAuthException catch (e) {
      setState(() => message = e.message ?? 'OTP যাচাই করা যায়নি।');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Icon(Icons.sports_soccer, size: 68, color: Color(0xFFE5BE55)),
                  const SizedBox(height: 12),
                  const Text('EF ARENA', textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, letterSpacing: 2, color: Color(0xFFE5BE55))),
                  const Text('PLAY • COMPETE • WIN', textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white60, letterSpacing: 2)),
                  const SizedBox(height: 42),
                  const Text('Welcome to the Arena', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  const Text('মোবাইল নম্বর দিয়ে লগইন করুন', style: TextStyle(color: Colors.white70)),
                  const SizedBox(height: 22),
                  TextField(
                    controller: phoneController,
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(
                      labelText: 'Phone Number / মোবাইল নম্বর',
                      hintText: '+8801XXXXXXXXX',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.phone),
                    ),
                  ),
                  const SizedBox(height: 12),
                  FilledButton(
                    onPressed: busy ? null : sendOtp,
                    child: Text(busy ? 'Please wait…' : 'Send OTP / OTP পাঠান'),
                  ),
                  if (verificationId != null) ...[
                    const SizedBox(height: 18),
                    TextField(
                      controller: otpController,
                      keyboardType: TextInputType.number,
                      maxLength: 6,
                      decoration: const InputDecoration(
                        labelText: '6-digit OTP',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    FilledButton.tonal(
                      onPressed: busy ? null : verifyOtp,
                      child: const Text('Verify & Login / যাচাই করুন'),
                    ),
                  ],
                  if (message.isNotEmpty) ...[
                    const SizedBox(height: 14),
                    Text(message, style: const TextStyle(color: Color(0xFFE5BE55))),
                  ],
                  const SizedBox(height: 18),
                  const Text('By continuing, you agree to the tournament rules.',
                    textAlign: TextAlign.center, style: TextStyle(color: Colors.white38, fontSize: 12)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final isAdmin = user != null && adminUid.isNotEmpty && user.uid == adminUid;
    final pages = <Widget>[
      const HomePage(),
      const TournamentPage(),
      const MatchesPage(),
      const RankingPage(),
      ProfilePage(isAdmin: isAdmin),
    ];
    const labels = ['Home', 'Tournaments', 'Matches', 'Ranking', 'Profile'];
    const icons = [Icons.home_outlined, Icons.emoji_events_outlined, Icons.sports_esports, Icons.leaderboard_outlined, Icons.person_outline];

    return Scaffold(
      appBar: AppBar(
        title: const Text('EF ARENA', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.5, color: Color(0xFFE5BE55))),
        actions: [
          IconButton(
            tooltip: 'Notifications',
            onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Notifications coming soon'))),
            icon: const Icon(Icons.notifications_none),
          ),
        ],
      ),
      body: IndexedStack(index: index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: List.generate(labels.length, (i) => NavigationDestination(icon: Icon(icons[i]), label: labels[i])),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(colors: [Color(0xFF302713), Color(0xFF171B22)], begin: Alignment.topLeft, end: Alignment.bottomRight),
            border: Border.all(color: const Color(0xFF8C7136)),
          ),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('WELCOME TO THE ARENA', style: TextStyle(color: Color(0xFFE5BE55), letterSpacing: 1.5, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Text('Play. Compete. Win.', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
            SizedBox(height: 6),
            Text('Your next victory starts here.', style: TextStyle(color: Colors.white70)),
          ]),
        ),
        const SizedBox(height: 20),
        const SectionTitle('Arena Overview / সংক্ষিপ্ত তথ্য'),
        const Row(children: [
          Expanded(child: StatCard(title: 'Tournaments', value: '—', icon: Icons.emoji_events)),
          SizedBox(width: 10),
          Expanded(child: StatCard(title: 'Players', value: '—', icon: Icons.groups)),
        ]),
        const SizedBox(height: 10),
        const Row(children: [
          Expanded(child: StatCard(title: 'Matches', value: '—', icon: Icons.sports_esports)),
          SizedBox(width: 10),
          Expanded(child: StatCard(title: 'Champions', value: '—', icon: Icons.military_tech)),
        ]),
        const SizedBox(height: 22),
        const SectionTitle('Featured Tournament / বিশেষ টুর্নামেন্ট'),
        const TournamentCard(
          name: 'EF ARENA Championship',
          format: 'eFootball Mobile • 1v1',
          entry: 'Free / Paid',
          prize: 'Prize Pool: Admin announcement',
          status: 'Coming Soon',
        ),
        const SizedBox(height: 20),
        const SectionTitle('Quick Rules / সংক্ষিপ্ত নিয়ম'),
        const Text('• সময়মতো ম্যাচ খেলুন\n• ফলাফলের স্ক্রিনশট জমা দিন\n• প্রতারণা বা ভুয়া ফলাফল নিষিদ্ধ',
          style: TextStyle(height: 1.8, color: Colors.white70)),
      ],
    );
  }
}

class TournamentPage extends StatelessWidget {
  const TournamentPage({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('tournaments').orderBy('createdAt', descending: true).snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) return const Center(child: Text('টুর্নামেন্ট লোড করা যায়নি।'));
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        final docs = snapshot.data!.docs;
        if (docs.isEmpty) {
          return const EmptyState(icon: Icons.emoji_events_outlined, title: 'No tournaments yet', subtitle: 'নতুন টুর্নামেন্ট শিগগিরই প্রকাশিত হবে।');
        }
        return ListView(
          padding: const EdgeInsets.all(16),
          children: docs.map((doc) {
            final d = doc.data();
            return TournamentCard(
              name: d['name'] ?? 'Untitled Tournament',
              format: '${d['game'] ?? 'eFootball Mobile'} • ${d['format'] ?? '1v1'}',
              entry: (d['entryFee'] ?? 0) == 0 ? 'Free Entry' : 'Entry Fee: ৳${d['entryFee']}',
              prize: 'Prize: ৳${d['prizePool'] ?? 0}',
              status: d['status'] ?? 'Open',
              onJoin: () => joinTournament(context, doc.id),
            );
          }).toList(),
        );
      },
    );
  }
}

Future<void> joinTournament(BuildContext context, String tournamentId) async {
  final user = FirebaseAuth.instance.currentUser;
  if (user == null) return;
  try {
    await FirebaseFirestore.instance.collection('registrations').add({
      'tournamentId': tournamentId,
      'playerUid': user.uid,
      'phoneNumber': user.phoneNumber,
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
    });
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('আবেদন জমা হয়েছে। Admin অনুমোদনের অপেক্ষায় থাকুন।')));
    }
  } catch (_) {
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('রেজিস্ট্রেশন করা যায়নি। পরে আবার চেষ্টা করুন।')));
    }
  }
}

class MatchesPage extends StatelessWidget {
  const MatchesPage({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return const SizedBox.shrink();
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('matches').where('playerUids', arrayContains: uid).snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) return const Center(child: Text('ম্যাচ লোড করা যায়নি।'));
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        if (snapshot.data!.docs.isEmpty) return const EmptyState(icon: Icons.sports_esports, title: 'No matches yet', subtitle: 'তোমার ম্যাচ এখানে দেখা যাবে।');
        return ListView(
          padding: const EdgeInsets.all(16),
          children: snapshot.data!.docs.map((doc) {
            final d = doc.data();
            return Card(child: ListTile(
              leading: const Icon(Icons.sports_soccer, color: Color(0xFFE5BE55)),
              title: Text(d['title'] ?? 'Tournament Match'),
              subtitle: Text('Status: ${d['status'] ?? 'Scheduled'}'),
              trailing: Text('${d['score'] ?? '—'}'),
            ));
          }).toList(),
        );
      },
    );
  }
}

class RankingPage extends StatelessWidget {
  const RankingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const EmptyState(
      icon: Icons.leaderboard_outlined,
      title: 'Leaderboard',
      subtitle: 'ম্যাচের ফলাফল যাচাই হওয়ার পর র‍্যাঙ্কিং এখানে দেখানো হবে।',
    );
  }
}

class ProfilePage extends StatelessWidget {
  final bool isAdmin;
  const ProfilePage({super.key, required this.isAdmin});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser!;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const CircleAvatar(radius: 38, child: Icon(Icons.person, size: 40)),
        const SizedBox(height: 12),
        Text(user.phoneNumber ?? 'EF ARENA Player', textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        const Text('eFootball Mobile Player', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60)),
        const SizedBox(height: 24),
        if (isAdmin) ...[
          const SectionTitle('Admin Control / অ্যাডমিন'),
          Card(
            child: ListTile(
              leading: const Icon(Icons.admin_panel_settings, color: Color(0xFFE5BE55)),
              title: const Text('Admin Panel'),
              subtitle: const Text('Create and manage tournaments'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminPage())),
            ),
          ),
        ],
        Card(
          child: ListTile(
            leading: const Icon(Icons.logout),
            title: const Text('Logout / লগআউট'),
            onTap: () => FirebaseAuth.instance.signOut(),
          ),
        ),
      ],
    );
  }
}

class AdminPage extends StatefulWidget {
  const AdminPage({super.key});

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  final name = TextEditingController();
  final fee = TextEditingController(text: '0');
  final prize = TextEditingController(text: '0');
  bool saving = false;

  @override
  void dispose() {
    name.dispose(); fee.dispose(); prize.dispose();
    super.dispose();
  }

  Future<void> createTournament() async {
    final title = name.text.trim();
    final entryFee = int.tryParse(fee.text.trim());
    final prizePool = int.tryParse(prize.text.trim());
    if (title.isEmpty || entryFee == null || prizePool == null || entryFee < 0 || prizePool < 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('সঠিক নাম ও টাকার পরিমাণ লিখুন।')));
      return;
    }
    setState(() => saving = true);
    try {
      await FirebaseFirestore.instance.collection('tournaments').add({
        'name': title,
        'game': 'eFootball Mobile',
        'format': '1v1',
        'entryFee': entryFee,
        'prizePool': prizePool,
        'status': 'Open',
        'createdAt': FieldValue.serverTimestamp(),
        'createdBy': FirebaseAuth.instance.currentUser!.uid,
      });
      name.clear();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Tournament created successfully!')));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('তৈরি করা যায়নি। Admin permission ও Firestore rules পরীক্ষা করুন।')));
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Admin Panel / অ্যাডমিন')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const SectionTitle('Create Tournament / টুর্নামেন্ট তৈরি'),
          TextField(controller: name, decoration: const InputDecoration(labelText: 'Tournament Name', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: fee, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Entry Fee (BDT) — 0 for Free', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: prize, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Prize Pool (BDT)', border: OutlineInputBorder())),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: saving ? null : createTournament,
            icon: const Icon(Icons.add),
            label: Text(saving ? 'Saving…' : 'Create Tournament'),
          ),
          const SizedBox(height: 24),
          const SectionTitle('Important'),
          const Text('এই starter-এ Admin UID build-time configuration দিয়ে দেখানো হয়েছে। Production-এ Firebase custom claims এবং server-side authorization ব্যবহার করতে হবে।',
            style: TextStyle(color: Colors.white70, height: 1.5)),
        ],
      ),
    );
  }
}

class TournamentCard extends StatelessWidget {
  final String name, format, entry, prize, status;
  final VoidCallback? onJoin;
  const TournamentCard({super.key, required this.name, required this.format, required this.entry, required this.prize, required this.status, this.onJoin});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.emoji_events, color: Color(0xFFE5BE55)),
            const SizedBox(width: 8),
            Expanded(child: Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17))),
            Text(status, style: const TextStyle(color: Color(0xFFB7F34A), fontSize: 12)),
          ]),
          const SizedBox(height: 10),
          Text(format, style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 6),
          Text(entry),
          Text(prize, style: const TextStyle(color: Color(0xFFE5BE55))),
          if (onJoin != null) ...[
            const SizedBox(height: 12),
            SizedBox(width: double.infinity, child: OutlinedButton(onPressed: onJoin, child: const Text('Join Tournament / যোগ দিন'))),
          ],
        ]),
      ),
    );
  }
}

class StatCard extends StatelessWidget {
  final String title, value;
  final IconData icon;
  const StatCard({super.key, required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(child: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: const Color(0xFFE5BE55)),
        const SizedBox(height: 10),
        Text(value, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        Text(title, style: const TextStyle(color: Colors.white60, fontSize: 12)),
      ]),
    ));
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Text(text, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
  );
}

class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  const EmptyState({super.key, required this.icon, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(28),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 54, color: const Color(0xFFE5BE55)),
        const SizedBox(height: 14),
        Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60)),
      ]),
    ),
  );
}
